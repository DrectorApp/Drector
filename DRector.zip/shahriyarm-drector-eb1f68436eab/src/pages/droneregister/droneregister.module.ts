import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DroneregisterPage } from './droneregister';

@NgModule({
  declarations: [
    DroneregisterPage,
  ],
  imports: [
    IonicPageModule.forChild(DroneregisterPage),
  ],
})
export class DroneregisterPageModule {}
